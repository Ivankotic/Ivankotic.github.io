import { createRouter, createMemoryHistory } from 'vue-router'
import TasksView from "../views/TasksView.vue";
import NotesView from "../views/NotesView.vue";
import DataView from "../views/DataView.vue";
import HelpView from "../views/HelpView.vue";
import JsonView from "../views/JsonView.vue";

const router = createRouter({
  history: createMemoryHistory(),
  routes: [
    {
      path: '/',
      name: "Задачи",
      component: TasksView
    },
    {
      path: '/notes',
      name: "Заметки",
      component: NotesView
    },
    {
      path: '/data',
      name: "Данные",
      component: DataView
    },
    {
      path: '/help',
      name: "Информация",
      component: HelpView
    },
    {
      path: '/json',
      name: "",
      component: JsonView,
    }
  ]
})

export default router
