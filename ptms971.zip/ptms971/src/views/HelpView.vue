<script setup>

</script>

<template>
  <p>ptms971 - приложение для упрощения управления личными задачами и заметками.</p>
</template>
